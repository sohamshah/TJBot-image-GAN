python speech_recog_demo.py
